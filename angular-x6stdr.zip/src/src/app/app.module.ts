import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpModule,Http } from '@angular/http';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { CreateComponent } from './create/create.component';
import { AboutComponent } from './about/about.component';
import { UpdateComponent } from './update/update.component';
import { DeleteComponent } from './delete/delete.component';

@NgModule({
  imports:      [ BrowserModule, FormsModule,HttpModule ],
  declarations: [ AppComponent, HelloComponent, CreateComponent, AboutComponent, UpdateComponent, DeleteComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
